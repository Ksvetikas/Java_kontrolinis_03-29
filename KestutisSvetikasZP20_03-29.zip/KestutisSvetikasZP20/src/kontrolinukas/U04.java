package kontrolinukas;

import java.util.Scanner;

public class U04 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Iveskite intervalo pradzia: ");
        int a = sc.nextInt();

        while (a < 1) {
            System.out.println("Intervalo pradzia turi buti didesne uz 0.");
            System.out.print("Iveskite intervalo pradzia: ");
            a = sc.nextInt();
        }

        System.out.print("Iveskite intervalo pabaiga: ");
        int b = sc.nextInt();

        while (a > b) {
            System.out.println("Intervalo pabaiga turi buti didesne uz intervalo pradzia.");
            System.out.print("Iveskite intervalo pradzia: ");
            b = sc.nextInt();
        }

        int kiekMarskineliu = 0;

        for (; a <= b; a++ ) {

            if (a % 6 == 0) {
                kiekMarskineliu++;
            }
        }

        System.out.println("Reikalingu marskineliu skaicius: " + kiekMarskineliu + ".");

        sc.close();
    }
}
