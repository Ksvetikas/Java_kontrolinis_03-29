package kontrolinukas;

import java.util.Scanner;

public class U02 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Iveskite deziu skaiciu: ");
        int dezes = sc.nextInt();

        System.out.println("Iveskite knygu skaiciu: ");
        int knygos = sc.nextInt();

        System.out.println("Iveskite kelios knygos telpa i deze: ");
        int kiekTelpa = sc.nextInt();

        int deziuTalpa = kiekTelpa * dezes;
        int skirtumas = knygos - deziuTalpa;

        if (skirtumas > 0 ) {
            System.out.println("Knygos netelpa i dezes.");
            System.out.println("I dezes netilpo " + skirtumas + "knygos/-a/-u.");
        }else {
            System.out.println("Knygos telpa i dezes.");
        }

        sc.close();
    }
}
