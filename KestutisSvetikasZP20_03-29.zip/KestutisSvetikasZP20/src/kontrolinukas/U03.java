package kontrolinukas;

public class U03 {

    public static void main(String[] args) {

        int intervaloPradzia = -100;
        int intervaloPabaiga = -199;

        System.out.println("Ciklas for:");

        for ( int i = intervaloPradzia; i >= intervaloPabaiga; i -= 3 ) {
            System.out.print(i + " ");
        }

        System.out.println("");
        System.out.println("Ciklas while:");

        int i = intervaloPradzia;

        while ( i >= intervaloPabaiga) {
            System.out.print(i + " ");
            i -= 3;
        }
    }
}
