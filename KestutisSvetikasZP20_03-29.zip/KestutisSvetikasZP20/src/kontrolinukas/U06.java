package kontrolinukas;

import java.util.Scanner;

public class U06 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Iveskite kiek kartu buvo mokomasi: ");
        System.out.println("");
        int n = sc.nextInt();

        int bendraTrukme = 0;

        for (int i = 0; i < n; i++) {

            System.out.println("Iveskite " + (i + 1) + " mokymosi periodo laikus.");
            System.out.println("");

            System.out.print("Iveskite mokymosi pradzios laiko valandas: ");
            int aVal = sc.nextInt();

            System.out.print("Iveskite mokymosi pradzios laiko minutes: ");
            int aMin = sc.nextInt();

            System.out.print("Iveskite mokymosi pabaigos laiko valandas: ");
            int bVal = sc.nextInt();

            System.out.print("Iveskite mokymosi pabaigos laiko minutes: ");
            int bMin = sc.nextInt();

            bendraTrukme += AlgoritmaiKestutis.gautiTrukmeMinutemis(aVal, aMin, bVal, bMin);

        }

        AlgoritmaiKestutis.gautiLaikoFormata(bendraTrukme);

        sc.close();
    }
}
