package kontrolinukas;

public class U05 {

    public static void main(String[] args) {

        AlgoritmaiKestutis.gautiGeriausiaIvertinima();
    }
}
