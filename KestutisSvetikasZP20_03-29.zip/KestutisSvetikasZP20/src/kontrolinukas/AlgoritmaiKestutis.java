package kontrolinukas;

import java.util.Arrays;
import java.util.Scanner;

public class AlgoritmaiKestutis {


//    U01

    public static void kiekPamoku() {

        Scanner sc = new Scanner(System.in);

        int pamokuSuma = 0;

        for (int i = 0; i < 5; i++){

            System.out.print("Kiek pamoku yra ");

            switch(i) {
                case (0):
                    System.out.print("pirmadieni? ");
                    break;
                case (1):
                    System.out.print("antradieni? ");
                    break;
                case (2):
                    System.out.print("treciadieni? ");
                    break;
                case (3):
                    System.out.print("ketvirtadieni? ");
                    break;
                default:
                    System.out.print("penktadieni? ");
                    break;
            }

            int kiekPamoku = sc.nextInt();

            pamokuSuma += kiekPamoku;
        }
        sc.close();

        System.out.println("Pamoku skaicius: " + pamokuSuma);
        System.out.println("Tai sudaro minuciu: " + pamokuSuma * 45);
    }

//    U05

    public static void gautiGeriausiaIvertinima() {

        Scanner sc = new Scanner(System.in);

        System.out.print("Iveskite pirmaji pazymi: ");
        int p1 = sc.nextInt();

        System.out.print("Iveskite antraji pazymi: ");
        int p2 = sc.nextInt();

        System.out.print("Iveskite treciaji pazymi: ");
        int p3 = sc.nextInt();

        int max = Math.max(p1, Math.max(p2, p3));

        System.out.println("Mokinio pazymys: " + max);

        sc.close();
    }

//    U06

    public static int gautiTrukmeMinutemis (int aVal, int aMin, int bVal, int bMin){

        int trukme = (((bVal * 60) + bMin) - ((aVal * 60) + aMin));

        return trukme;
    }

    public static void gautiLaikoFormata (int trukme) {

        int trukmeVal = trukme / 60;
        int trukmeMin = trukme % 60;

        System.out.println(trukmeVal + "val. " + trukmeMin + "min.");
    }

//    U07

    public static void print(int [] array) {

        System.out.println(Arrays.toString(array));
    }


    public static boolean equals(int[] array1, int[] array2){


        if (array1.length == array2.length) {

            for (int i = 0 ; i < array1.length; i++) {

                if (!(array1[i] == array2[i])){
                    return false;
                }
            }

            return true;

        }else {
            return false;
        }
    }
}

