package kontrolinukas;

public class TestAlgoritmaiKestutis {

    public static void main(String[] args) {

        int [] array1 = {1, 2 , 3, 4};
        int [] array2 = {1, 2 , 3, 4};
        int [] array3 = {1, 2 , 3, 3};

        AlgoritmaiKestutis.print(array1);
        System.out.println(AlgoritmaiKestutis.equals(array1, array2));
        System.out.println(AlgoritmaiKestutis.equals(array1, array3));
    }
}
