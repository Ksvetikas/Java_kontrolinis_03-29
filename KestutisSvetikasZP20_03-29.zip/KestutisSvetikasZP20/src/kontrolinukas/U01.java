package kontrolinukas;


public class U01 {

    public static void main(String[] args) {

        AlgoritmaiKestutis.kiekPamoku();
    }
}
